$(document).ready(function() {
    $('.reference-number-filter').change(function (event) {
        var url = window.location.href;
        if (url.indexOf('?') > -1){
           url = url.replace(url.substring(url.indexOf("?reference-number=")),"");
        }
        if ($('.reference-number-filter').val() != "") {
            url += '?reference-number=' + $('.reference-number-filter').val();
        }
        window.location.href = url;
    });
});